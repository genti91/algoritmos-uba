#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char const *argv[])
{   
    if (argc < 2 || argc > 3 || !atoi(argv[1]))
    {
        fputs("Error: Cantidad erronea de parametros\n", stderr);
        return -1;
    }

    int max_chars = atoi(argv[1]);
    
    if (argc == 2)
    {
        char* linea = NULL;
        size_t tam;

        while ((getline(&linea, &tam, stdin)) != EOF)
        {   
            int contador = 1;
            for (size_t i = 0; i < strlen(linea); i++)
            {   
                if (linea[i] != '\n')
                {
                    fputc(linea[i], stdout);
                }

                if (contador == max_chars && linea[i] != '\n')
                {
                   fputc('\n', stdout);
                   contador = 0;
                }
                contador++;
            }

            if (strlen(linea)-2 != max_chars && strlen(linea)-2 > max_chars)
            {
                fputc('\n', stdout);
                
            }
        }
        free(linea);
        return 0;
    }


    FILE* archivo = fopen(argv[2], "r");

    if (archivo == NULL){
        fputs("Error: archivo fuente inaccesible\n", stderr);
        return -1;
    }

    char* linea = NULL;
        size_t tam;

    while ((getline(&linea, &tam, archivo)) != EOF)
    {   
        int contador = 1;
        for (size_t i = 0; i < strlen(linea); i++)
        {   
            if (linea[i] != '\n')
            {
                fputc(linea[i], stdout);
            }

            if (contador == max_chars && linea[i] != '\n')
            {
                fputc('\n', stdout);
                contador = 0;
            }
            contador++;
        }

        if (strlen(linea)-2 != max_chars && strlen(linea)-2 > max_chars)
        {
            fputc('\n', stdout);
                
        }
    }

    free(linea);
    fclose(archivo);

    return 0;
}